import React from "react";

const Home = () => {
  return (
    <>
      <section className="home" id="home">
        <div className="content">
          <h3>
            fresh <span>food in the </span>morning
          </h3>
          <p>
          Food can be special because it reminds us of home, family, or a cherished memory. Grandma's homemade pie or a traditional dish prepared during festivals often tastes irreplaceable.
          </p>
          <a href="#" className="btn">
            get yours now
          </a>
        </div>
      </section>
    </>
  );
};

export default Home;
